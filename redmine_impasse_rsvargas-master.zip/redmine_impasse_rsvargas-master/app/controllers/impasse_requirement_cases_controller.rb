class ImpasseRequirementCasesController < ImpasseAbstractController
  unloadable

end
