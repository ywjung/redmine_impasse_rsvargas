require File.dirname(__FILE__) + '/../test_helper'

class NodeHierarchyTest < ActiveSupport::TestCase
  fixtures :node_hierarchies

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
