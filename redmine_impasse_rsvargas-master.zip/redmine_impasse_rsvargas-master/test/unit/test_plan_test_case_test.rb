require File.dirname(__FILE__) + '/../test_helper'

class TestPlanTestCaseTest < ActiveSupport::TestCase
  fixtures :test_plan_test_cases

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
