require File.dirname(__FILE__) + '/../test_helper'

class TestCaseVersionTest < ActiveSupport::TestCase
  fixtures :test_case_versions

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
