require File.dirname(__FILE__) + '/../test_helper'

class Impasse::ExecutionHistoryTest < ActiveSupport::TestCase
  fixtures :impasse_execution_histories

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
