require File.dirname(__FILE__) + '/../test_helper'

class Impasse::KeywordsTest < ActiveSupport::TestCase
  fixtures :impasse_keywords

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
