require File.dirname(__FILE__) + '/../test_helper'

class Impasse::SettingTest < ActiveSupport::TestCase
  fixtures :impasse_settings

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
