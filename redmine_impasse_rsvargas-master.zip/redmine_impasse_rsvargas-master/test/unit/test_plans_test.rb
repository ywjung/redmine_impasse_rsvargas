require File.dirname(__FILE__) + '/../test_helper'

class TestPlansTest < ActiveSupport::TestCase
  fixtures :test_plans

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
